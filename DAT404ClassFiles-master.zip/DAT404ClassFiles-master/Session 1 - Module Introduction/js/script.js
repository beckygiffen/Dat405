function sum(a,b)
{
  return a + b;
}//This creates a function called sum, that accepts two parameters called a and b, and returns the sum of these parameters

var total = sum(7,11); // This passes 7 and 11 into the sum function, and stores the returned data in a var called total
alert(total);// this creates an alert box/pop up, with the total written inside

document.getElementById("date").innerHTML = Date();
//This looks at our Document, finds an element with the ID if date, and writes the current date insise, as html
